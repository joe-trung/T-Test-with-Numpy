import pandas as pd
import numpy as np
from scipy import stats

def computeTandP(arr1, arr2):
    mean1, mean2 = np.mean(arr1), np.mean(arr2)
    print("arr1 mean math scores:" , mean1)
    print("arr2  mean math scores:" , mean2)
    # Null Hypotheses Math Test Scores are the same for males and females

    # get the standard deviation of each set
    s1 = np.std(arr1) 
    s2 = np.std(arr2)

    # pool the variance since they are different population sizes
    # 
    var = (((arr1.size -1)*(s1**2)) + ((arr2.size -1)*(s2**2))) / (arr1.size+arr2.size-2)
    sp = np.sqrt(var) # standard deviation
    ste = sp * np.sqrt(1/arr1.size + 1/arr2.size) # standard error
    
    # t test = difference of mean /standard error of difference

    t = (mean1 - mean2)/ste
    
    # how much the scores deviate from the mean

    print("TScore: ", t)
    df = (arr1.size + arr2.size) - 2
    print("Degrees of Freedom", df)
    p = 2*(1-stats.t.cdf(t, df))
    print("p score: ", p)

    return t,p

# task 5 remove outliers
#Calculate the Interquartile range IQR to remove outliers
# IQR = third quartile q3, the middle of the upper quartile -- median above the median
#         minus the first quartile q1, the lower quartile -- median below the median
# IQR = q3-q1
# Lower limit = q1 - 1.5*IQR
# Upper Limit = q3 + 1.5*IQR
def removeOutliers(arr):
    q3, q1 = np.percentile(arr, [75 ,25])
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    print ("lower outlier limit = ", lower)
    print ("upper outlier limit = ", upper)
    # remove elements below lower and above upper 
    # by keeping between lower and upper, inclusive
    arr = arr[(arr >=lower) & (arr <= upper)]
    return arr

df = pd.read_csv("scores.csv")
print (df.shape)

print (df)

fm = df.loc[df['gender'] == 'female', 'math score'].values

print(fm)
mm   = df.loc[df['gender'] == 'male', 'math score'].values


# females = df['math score'] & df['gender'] == 'female'
print("Females: \n", fm)
print("Males: \n" , mm)

meanF, meanM = np.mean(fm), np.mean(mm)
print("Female mean math scores:" , meanF)
print("Male mean math scores:" , meanM)
# Null Hypotheses Math Test Scores are the same for males and females

print("min value of male score before outlier removal:", np.amin(mm))
print("min value of female score before outlier removal:", np.amin(fm))
tvalue, pvalue = computeTandP(mm,fm)
print("T Value:" , tvalue)
print("P Value:" , pvalue)

fm = removeOutliers(fm)
mm = removeOutliers(mm)

print("min value of male score after outlier removal:", np.amin(mm))
print("min value of female score after outlier removal:", np.amin(fm))
tvalue, pvalue = computeTandP(mm,fm)
print("T Value:" , tvalue)
print("P Value:" , pvalue)
std1 = np.std(mm) 
std2 = np.std(fm)
mean1, mean2 = np.mean(mm), np.mean(fm)
# perform a t-test using the scipi package
# the two samples have different sizes so we use a two-sided test with stats
ts, ps = stats.ttest_ind_from_stats(mean1,std1,mm.size,mean2,std2,fm.size,1)
print ("T value from stats:", ts)
print ("P value from stats:", ps)
print(mm.size, fm.size)


